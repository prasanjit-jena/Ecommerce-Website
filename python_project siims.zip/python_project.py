'''class StudentsData:
    iname='nth'
    fee=5000
    def __init__(self,name,marks):
        self.name=name
        self.marks=marks
    def display(self):
        print('students name: ',self.name)
        print('students marks: ',self.marks)
        print('institute name: ',StudentsData.iname)
        print('course fee: ',StudentsData.fee)
import pymysql
connection=pymysql.connect(host='localhost',user='root',password='ajit',db='ajitdb')
c=connection.cursor()
c.execute('select* from ajitdata;')
data=c.fetchall()
for i in data:
    name=i[1]
    marks=i[2]
    s=StudentsData(name,marks)
    s.display()
    print()'''
'''class StudentsData:
    def __init__(self,name,percentage):
        self.name=name
        self.percentage=percentage
    def display(self):
        print('StudentName: ',self.name)
        print('StudentPercentage: ',self.percentage)
    @classmethod
    def getpercentage(cls,name,marks):
        return cls(name,(marks/600)*100)
name='dhoni'
marks=453
s=StudentsData.getpercentage(name,marks)
s.display()'''
'''
def revword(a):
    'blue i am greener than'
    b=a.split()
    #c=b[::-1]
    str=''
    for i in b:
        str=i+' ' + str
    print(str)
b='pradhan ajit kumar'
revword(b)
'''
'''
def number():
    for i in range(1,10000):
        if i%5==0 and i%10==0:
            print(i)

n=number()
print(n)
'''
'''a=10
print(a)
def oo():
    global a
    a=a+5
    print(a)
oo()
def oo1():
    print(a)
oo1()'''

'''
#update dictionary to dictionary
ajit={'name':'ajit','dist=':'dkl','state':'odisha'}
kumar={'name':'sai','loc':'hyd'}
kumar.update(ajit)
print(kumar)
'''

'''
#delete from dictionary
ajit={'name':'ajit','dist':'dkl','state':'odisha'}
ajit.pop('dist')
print(ajit)

ajit={'name':'ajit','dist':'dkl','state':'odisha'}
ajit.popitem()
print(ajit)
'''
'''retrieve
ajit={'name':'ajit','dist':'dkl','state':'odisha'}
print(ajit)
print(ajit['name'])
'''

'''adding new key values
ajit={'name':'ajit','dist':'dkl','state':'odisha'}
ajit['salary']='50k'
ajit['mstatus']='um married'
print(ajit)
'''
'''
ajit={'name':'ajit','dist':'dkl','state':'odisha'}
print(ajit.keys())
print(ajit.values())
print(ajit.items())
print(ajit)
'''
'''
dict=10,20,30,40,50
data={}.fromkeys(dict,'ajit')
print(data[20]+'pradhan')
'''

#SIMS(Sudents Information Management System)
'''
from tkinter import *
from tkinter import ttk
import pymysql
class StudentsInfo:
    def __init__(self,root):
        self.root=root
        self.root.geometry('1550x780')
        self.root.title('NTH')
        title1= Label(self.root,text='welcome to nth students information', font=('Cooper Black',40,'bold'),bg='green',fg='white')
        title1.pack(fill='x')
        
       

        self.rollnoVar=StringVar()
        self.firstnameVar=StringVar()
        self.lastnameVar=StringVar()
        self.emailidVar=StringVar()
        self.contactVar=StringVar()
        self.courseVar=StringVar()
        self.locationVar=StringVar()

        #creating frames
        dataEntryFrame=Frame(self.root,bg='green')
        dataEntryFrame.place(x=4,y=70,width=500,height=700)
        datadisplayframe=Frame(self.root, bg='green')
        datadisplayframe.place(x=510,y=70,width=1050,height=700)
        #working with data entry frame
        title2=Label(dataEntryFrame,text='Data Entry Here...',font=('Cooper Black',20,'bold'),bg='green',fg='white')
        title2.grid(row=0,columnspan=2,padx=100,pady=20)
        
        #Roll no
        roll_no=Label(dataEntryFrame,text='Roll No:',font=('Arial',20,'bold'),bg='green',fg='white')
        roll_no.grid(row=1,column=0,sticky='w')
        roll_no_entry=Entry(dataEntryFrame, textvariable = self.rollnoVar, font=('Arial',20,'bold'),bg='white',fg='black')
        roll_no_entry.grid(row=1,column=1,sticky='s',pady=10)

        #first_name
        first_name=Label(dataEntryFrame,text='First Name:',font=('Arial',20,'bold'),bg='green',fg='white')
        first_name.grid(row=2,column=0,sticky='w')
        first_name_entry=Entry(dataEntryFrame, textvariable = self.firstnameVar, font=('Arial',20,'bold'),bg='white',fg='black')
        first_name_entry.grid(row=2,column=1,sticky='s',pady=10)

        #last_name
        last_name=Label(dataEntryFrame,text='Last Name:',font=('Arial',20,'bold'),bg='green',fg='white')
        last_name.grid(row=3,column=0,sticky='w')
        last_name_entry=Entry(dataEntryFrame, textvariable = self.lastnameVar, font=('Arial',20,'bold'),bg='white',fg='black')
        last_name_entry.grid(row=3,column=1,sticky='s',pady=10)

        #email
        email=Label(dataEntryFrame,text='Email Id:',font=('Arial',20,'bold'),bg='green',fg='white')
        email.grid(row=4,column=0,sticky='w')
        email_entry=Entry(dataEntryFrame, textvariable = self.emailidVar, font=('Arial',20,'bold'),bg='white',fg='black')
        email_entry.grid(row=4,column=1,sticky='s',pady=10)
        #contact
        contact=Label(dataEntryFrame,text='Contact:',font=('Arial',20,'bold'),bg='green',fg='white')
        contact.grid(row=5,column=0,sticky='w')
        contact_entry=Entry(dataEntryFrame, textvariable = self.contactVar, font=('Arial',20,'bold'),bg='white',fg='black')
        contact_entry.grid(row=5,column=1,sticky='s',pady=10)
        #course
        course=Label(dataEntryFrame,text='Course:',font=('Arial',20,'bold'),bg='green',fg='white')
        course.grid(row=6,column=0,sticky='w')
        course_entry=Entry(dataEntryFrame, textvariable = self.courseVar, font=('Arial',20,'bold'),bg='white',fg='black')
        course_entry.grid(row=6,column=1,sticky='s',pady=10)
        #location
        location=Label(dataEntryFrame,text='Location:',font=('Arial',20,'bold'),bg='green',fg='white')
        location.grid(row=7,column=0,sticky='w')
        location_entry=Entry(dataEntryFrame, textvariable = self.locationVar, font=('Arial',20,'bold'),bg='white',fg='black')
        location_entry.grid(row=7,column=1,sticky='s',pady=10)

        #creatintng frame for buttons
        frame_button=Frame(dataEntryFrame,bg='green',border=4,relief='groove')
        frame_button.place(x=10,y=500,width=480,height=150)
        
        #add buttons
        add=Button(frame_button,text='Add',command=self.adding, font=('Arial',20,'bold'),bg='red',fg='white')
        add.grid(row=0,column=0,pady=40,padx=8)
        update=Button(frame_button,text='Update', command=self.updating, font=('Arial',20,'bold'),bg='black',fg='white')
        update.grid(row=0,column=1,pady=40,padx=8)
        delete=Button(frame_button,text='Delete', command=self.deleting, font=('Arial',20,'bold'),bg='blue',fg='white')
        delete.grid(row=0,column=2,pady=40,padx=9)
        clear=Button(frame_button,text='Clear', command=self.clearing, font=('Arial',20,'bold'),bg='orange',fg='white')
        clear.grid(row=0,column=3,pady=40,padx=8)

        #working with Data display frame
        title3=Label(datadisplayframe,text='Data Display Here',font=('Cooper Black',20,'bold'),bg='green',fg='black') 
        title3.place(x=300, y=20)

        #creatintng frame for data display table
        tableFrame=Frame(datadisplayframe, width=1000, height=560, bg='green',border=4,relief='raised')
        tableFrame.place(x=5,y=85)

        self.StudentsData=ttk.Treeview(tableFrame, columns=('roll_no','first_name','last_name','emailid','contact','course','location'))

        self.StudentsData.heading('roll_no',text='Roll No')
        self.StudentsData.heading('first_name',text='First Name')
        self.StudentsData.heading('last_name',text='Last Name')
        self.StudentsData.heading('emailid',text='Email ID')
        self.StudentsData.heading('contact',text='Contact No')
        self.StudentsData.heading('course',text='Course')
        self.StudentsData.heading('location',text='Location')

        self.StudentsData['show']='headings'

        self.StudentsData.column('roll_no', width=100,anchor='center')
        self.StudentsData.column('first_name', width=110,anchor='center')
        self.StudentsData.column('last_name', width=110,anchor='center')
        self.StudentsData.column('emailid', width=130,anchor='center')
        self.StudentsData.column('contact', width=130,anchor='center')
        self.StudentsData.column('course', width=130,anchor='center')
        self.StudentsData.column('location', width=120,anchor='center')

        self.StudentsData.pack()
        self.fetching()
        self.StudentsData.bind("<ButtonRelease-1>", self.get_cursor)

    def adding(self):
        connection=pymysql.connect(host='localhost',user='root',password='ajit',db='studentsinfo')
        c=connection.cursor()
        c.execute('insert into studentsdata values(%s,%s,%s,%s,%s,%s,%s)',
                (
                    self.rollnoVar.get(),
                    self.firstnameVar.get(),
                    self.lastnameVar.get(),
                    self.emailidVar.get(),
                    self.contactVar.get(),
                    self.courseVar.get(),
                    self.locationVar.get()
                        ))
        connection.commit()
        self.fetching()
        self.clearing()
        connection.close()

    def clearing(self):
            self.rollnoVar.set(''),
            self.firstnameVar.set(''),
            self.lastnameVar.set(''),
            self.emailidVar.set(''),
            self.contactVar.set(''),
            self.courseVar.set(''),
            self.locationVar.set('')

    def fetching(self):
        connection=pymysql.connect(host='localhost',user='root',password='ajit',db='studentsinfo')
        c=connection.cursor()
        c.execute('select * from studentsdata')
        data=c.fetchall()
        self.StudentsData.delete(*self.StudentsData.get_children())
        for i in data:
            self.StudentsData.insert('', END, value=i)
        connection.commit()
        connection.close()

    def get_cursor(self,dataDisplay_enryBox):
        cursor_row=self.StudentsData.focus()
        content=self.StudentsData.item(cursor_row)
        row=content['values']
        self.rollnoVar.set(row[0])
        self.firstnameVar.set(row[1])
        self.lastnameVar.set(row[2])
        self.emailidVar.set(row[3])
        self.contactVar.set(row[4])
        self.courseVar.set(row[5])
        self.locationVar.set(row[6])

    def updating(self):
        connection=pymysql.connect(host='localhost',user='root',password='ajit',db='studentsinfo')
        c=connection.cursor()
        c.execute('update StudentsData set fname=%s, lname=%s, emailid=%s, contact=%s, course=%s, location=%s where id=%s',
                  (
                    self.firstnameVar.get(),
                    self.lastnameVar.get(),
                    self.emailidVar.get(),
                    self.contactVar.get(),
                    self.courseVar.get(),
                    self.locationVar.get(),
                    self.rollnoVar.get()
                        ))
        connection.commit()
        self.fetching()
        self.clearing()
        connection.close()

    def deleting(self):
        connection=pymysql.connect(host='localhost',user='root',password='ajit',db='studentsinfo')
        c=connection.cursor()
        c.execute('delete from StudentsData where id=%s', self.rollnoVar.get())
        connection.commit()
        self.fetching()
        self.clearing()
        connection.close()


ajit=Tk()
obj=StudentsInfo(ajit)
ajit.mainloop()
'''








